import torch
import torch.nn as nn
import torchvision.models as models

class I3DModel(nn.Module):
    def __init__(self, num_classes):
        super(I3DModel, self).__init__()
        self.i3d = models.video.r3d_18(pretrained=True)  # Load the 3D ResNet model
        self.i3d.fc = nn.Linear(self.i3d.fc.in_features, num_classes)  # Adjust for number of classes

    def forward(self, x):
        return self.i3d(x)

# Example of initializing the model with 1000 classes
model = I3DModel(num_classes=1000)

# Check the model's architecture
print(model)
