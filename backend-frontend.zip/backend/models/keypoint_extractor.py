import mediapipe as mp
import numpy as np
import cv2

# Initialize MediaPipe Holistic model
mp_holistic = mp.solutions.holistic
mp_drawing = mp.solutions.drawing_utils

# Function to extract keypoints
def extract_keypoints(image):
    with mp_holistic.Holistic(min_detection_confidence=0.5, min_tracking_confidence=0.5) as holistic:
        # Process the image
        image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        results = holistic.process(image_rgb)
        
        keypoints = []
        # Extracting Pose landmarks
        if results.pose_landmarks:
            for landmark in results.pose_landmarks.landmark:
                keypoints.append([landmark.x, landmark.y, landmark.z])
        else:
            keypoints += [[0, 0, 0]] * 33  # If no landmarks, append zeros
        
        # Extracting Hand landmarks (left & right hands)
        if results.left_hand_landmarks:
            for landmark in results.left_hand_landmarks.landmark:
                keypoints.append([landmark.x, landmark.y, landmark.z])
        else:
            keypoints += [[0, 0, 0]] * 21  # If no landmarks, append zeros
        
        if results.right_hand_landmarks:
            for landmark in results.right_hand_landmarks.landmark:
                keypoints.append([landmark.x, landmark.y, landmark.z])
        else:
            keypoints += [[0, 0, 0]] * 21  # If no landmarks, append zeros
        
        # Extracting Face landmarks
        if results.face_landmarks:
            for landmark in results.face_landmarks.landmark:
                keypoints.append([landmark.x, landmark.y, landmark.z])
        else:
            keypoints += [[0, 0, 0]] * 468  # If no landmarks, append zeros
        
        return np.array(keypoints).flatten()

# Capture a video feed (for demo purposes)
cap = cv2.VideoCapture(0)
frame_count = 0
sequence_frames = []

while True:
    ret, frame = cap.read()
    if not ret:
        break

    keypoints = extract_keypoints(frame)
    sequence_frames.append(keypoints)
    
    # Collect 32 frames per gesture
    if len(sequence_frames) == 32:
        # Process the sequence for training
        sequence_frames = []  # Reset the sequence for the next gesture

    cv2.imshow("Camera Feed", frame)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
