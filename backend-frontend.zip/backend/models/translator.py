from transformers import BartForConditionalGeneration, BartTokenizer

class SignLanguageTranslator:
    def __init__(self):
        self.model = BartForConditionalGeneration.from_pretrained('facebook/bart-large')
        self.tokenizer = BartTokenizer.from_pretrained('facebook/bart-large')

    def translate(self, sign_text):
        inputs = self.tokenizer(sign_text, return_tensors="pt", padding=True)
        translated = self.model.generate(**inputs)
        translated_text = self.tokenizer.decode(translated[0], skip_special_tokens=True)
        return translated_text

# Example usage
translator = SignLanguageTranslator()
translated_text = translator.translate("hello world")
print(translated_text)  # Example output: Bonjour le monde
