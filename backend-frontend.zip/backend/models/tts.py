from gtts import gTTS
import os

def text_to_speech(text, language='en'):
    tts = gTTS(text=text, lang=language)
    tts.save("output.mp3")
    os.system("start output.mp3")  # Will work on Windows, use appropriate command on Linux/Mac

# Example usage
text_to_speech("Hello, how are you?", language="en")
