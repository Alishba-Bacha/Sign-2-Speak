import torch
from transformers import CLIPProcessor, CLIPModel

class CLIPModelFusion:
    def __init__(self):
        self.processor = CLIPProcessor.from_pretrained("openai/clip-vit-base-patch32")
        self.model = CLIPModel.from_pretrained("openai/clip-vit-base-patch32")

    def forward(self, image, text):
        inputs = self.processor(text=text, images=image, return_tensors="pt", padding=True)
        outputs = self.model(**inputs)
        return outputs.logits_per_image

# Example usage
clip_model = CLIPModelFusion()
image = torch.randn(1, 3, 224, 224)  # Example image tensor
text = ["Hello"]
output = clip_model.forward(image, text)
