// api.js

// This function will call the Flask API to send the keypoints (sequence of frames) and get the prediction.
export async function getPrediction(sequenceFrames) {
    const response = await fetch('http://localhost:5000/predict', {
        method: 'POST', // Use POST as we are sending data
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            frames: sequenceFrames
        }),
    });

    if (!response.ok) {
        throw new Error('Failed to fetch prediction');
    }

    const data = await response.json();
    return data.predicted_sign; // Return the predicted sign language text
}
