// Example React component that uses video_feed.js and api.js

import React, { useState } from 'react';
import { getPrediction } from './api';
import './video_feed';

function SignLanguageTranslator() {
    const [prediction, setPrediction] = useState('');

    // Callback for when the prediction is received
    function handlePrediction(newPrediction) {
        setPrediction(newPrediction);
    }

    // Listen for predicted sign
    window.addEventListener('prediction', (event) => {
        handlePrediction(event.detail);
    });

    return (
        <div>
            <h1>Sign Language Translator</h1>
            <video id="videoElement" width="640" height="480" />
            <div>
                <h2>Prediction</h2>
                <p>{prediction}</p>
            </div>
        </div>
    );
}

export default SignLanguageTranslator;
