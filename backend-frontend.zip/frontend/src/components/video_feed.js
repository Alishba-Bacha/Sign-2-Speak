// video_feed.js

import { getPrediction } from './api.js';

const videoElement = document.querySelector('#videoElement'); // Your video HTML element
let sequenceFrames = [];

// Initialize the video feed
async function initVideoFeed() {
    const constraints = {
        video: {
            facingMode: "user", // Front camera
            width: { ideal: 1280 },
            height: { ideal: 720 },
        },
    };

    try {
        const stream = await navigator.mediaDevices.getUserMedia(constraints);
        videoElement.srcObject = stream;
        videoElement.play();
    } catch (error) {
        console.error('Error accessing the camera:', error);
    }
}

// Process the video frames using MediaPipe for keypoint extraction
async function processFrame() {
    // Assuming you have a function `extractKeypoints` that uses MediaPipe to extract the keypoints
    const keypoints = await extractKeypointsFromVideoFrame(videoElement);
    sequenceFrames.push(keypoints);

    // Process the frames when we have collected 32 frames (for gesture recognition)
    if (sequenceFrames.length === 32) {
        try {
            const prediction = await getPrediction(sequenceFrames);
            displayPrediction(prediction);
        } catch (error) {
            console.error('Error during prediction:', error);
        }

        // Reset sequence frames after sending to API
        sequenceFrames = [];
    }
}

// Display the predicted sign language text
function displayPrediction(prediction) {
    const predictionElement = document.querySelector('#prediction');
    predictionElement.innerText = `Predicted Sign Language: ${prediction}`;
}

// Function to extract keypoints using MediaPipe (you need to integrate MediaPipe here)
async function extractKeypointsFromVideoFrame(videoElement) {
    // Placeholder code: Implement MediaPipe-based keypoint extraction here
    // For now, let's return dummy data (replace with your actual extraction code)
    return new Array(63).fill(0); // Example: 63 is just a placeholder for keypoint dimensions
}

// Capture the frames every 100ms for real-time inference
setInterval(processFrame, 100); // Adjust timing based on your needs

// Start the video feed when the page is loaded
window.onload = () => {
    initVideoFeed();
};
