import torch
import torch.nn as nn
import math

class PositionalEncoding(nn.Module):
    def __init__(self, d_model, max_len=500):
        super().__init__()
        pe = torch.zeros(max_len, d_model)  # (T, D)
        position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)  # (T, 1)
        div_term = torch.exp(torch.arange(0, d_model, 2).float() * (-math.log(10000.0) / d_model))  # (D/2,)

        pe[:, 0::2] = torch.sin(position * div_term)  # Even idx
        pe[:, 1::2] = torch.cos(position * div_term)  # Odd idx
        pe = pe.unsqueeze(0)  # Shape: (1, T, D)
        self.register_buffer('pe', pe)

    def forward(self, x):
        # x: (B, T, D)
        x = x + self.pe[:, :x.size(1)]
        return x


class SignLanguageTransformer(nn.Module):
    def __init__(self, input_size=63, cnn_output_size=256, num_classes=100, nhead=8, num_layers=4, dropout=0.1):
        super(SignLanguageTransformer, self).__init__()

        # Per-frame feature transformation (like a CNN)
        self.frame_encoder = nn.Sequential(
            nn.Linear(input_size, 512),
            nn.BatchNorm1d(512),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(512, cnn_output_size),
            nn.BatchNorm1d(cnn_output_size),
            nn.ReLU()
        )

        # Positional encoding for temporal information
        self.pos_encoder = PositionalEncoding(d_model=cnn_output_size)

        # Transformer Encoder for temporal modeling
        encoder_layer = nn.TransformerEncoderLayer(d_model=cnn_output_size, nhead=nhead, dropout=dropout, batch_first=True)
        self.transformer = nn.TransformerEncoder(encoder_layer, num_layers=num_layers)

        # Final classifier
        self.classifier = nn.Linear(cnn_output_size, num_classes)

    def forward(self, keypoints):
        """
        Forward pass for the SignLanguageTransformer.
        :param keypoints: (B, T, K), where B is batch size, T is time steps, and K is keypoints per frame
        :return: Class predictions (B, num_classes)
        """
        B, T, K = keypoints.size()
        
        # Flatten keypoints into the shape that the frame encoder can process
        keypoints = keypoints.view(B * T, K)  # (B*T, K)

        # Pass through the frame encoder
        x = self.frame_encoder(keypoints)  # (B*T, D)
        x = x.view(B, T, -1)  # (B, T, D) - reshape to (batch_size, time_steps, feature_dim)

        # Add positional encoding
        x = self.pos_encoder(x)

        # Pass through the transformer
        x = self.transformer(x)  # (B, T, D)

        # Pooling over time steps (mean or other operation)
        x = x.mean(dim=1)  # Mean pooling over time steps → (B, D)

        # Final classification layer
        out = self.classifier(x)  # (B, num_classes)
        return out


def load_keypoints(keypoints_path):
    """
    Load keypoints from a .pt file.
    :param keypoints_path: Path to the .pt file containing the keypoints
    :return: Keypoints tensor (T, K) where T is the number of time steps (frames), and K is the number of keypoints
    """
    keypoints = torch.load(keypoints_path)
    return keypoints.float() # Shape: (T, K) where T is time steps, K is keypoints


# Example usage:
if __name__ == "__main__":
    # Example of loading the keypoints from .pt file
    keypoints_path = 'C:/Users/DELL/Desktop/NLP_CV_Project/sign2speak/keypoints/00625.pt'
    keypoints = load_keypoints(keypoints_path)  # Shape: (T, K)
    #keypoints = keypoints.float()

    # Define model
    model = SignLanguageTransformer(input_size=keypoints.size(1))  # Input size is the number of keypoints

    # Add batch dimension for batch processing
    keypoints = keypoints.unsqueeze(0)  # Shape: (1, T, K) for a single sample batch
    
    # Forward pass through the model
    output = model(keypoints)
    print(output.shape)  # Output shape: (1, num_classes) for a single batch
