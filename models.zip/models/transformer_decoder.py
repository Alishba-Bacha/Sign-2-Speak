from transformers import T5ForConditionalGeneration, T5Tokenizer
import torch
import torch.nn as nn
import torch.nn.functional as F

class GestureToTextDecoder(nn.Module):
    def __init__(self, model_name="t5-small"):
        super(GestureToTextDecoder, self).__init__()
        self.model = T5ForConditionalGeneration.from_pretrained(model_name)
        self.tokenizer = T5Tokenizer.from_pretrained(model_name)

    def forward(self, gesture_features):
        input_text = "Translate this gesture: " + gesture_features
        input_ids = self.tokenizer.encode(input_text, return_tensors="pt")

        output_ids = self.model.generate(input_ids)
        generated_text = self.tokenizer.decode(output_ids[0], skip_special_tokens=True)
        return generated_text
