import os
import cv2
import json
import numpy as np
import mediapipe as mp
from tqdm import tqdm

def extract_keypoints_from_frame(frame, hands_model):
    image_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    results = hands_model.process(image_rgb)

    if results.multi_hand_landmarks:
        hand = results.multi_hand_landmarks[0]  # use first hand
        keypoints = []
        for lm in hand.landmark:
            keypoints.extend([lm.x, lm.y, lm.z])
        return keypoints
    return None

def process_wlasl(json_path, video_dir, output_dir):
    os.makedirs(output_dir, exist_ok=True)
    
    with open(json_path, 'r') as f:
        annotations = json.load(f)

    mp_hands = mp.solutions.hands.Hands(
        static_image_mode=False,
        max_num_hands=1,
        min_detection_confidence=0.5,
        min_tracking_confidence=0.5
    )

    for entry in tqdm(annotations, desc="Processing videos"):
        for instance in entry.get("instances", []):
            video_id = instance["video_id"]
            video_path = os.path.join(video_dir, f"{video_id}.mp4")
            if not os.path.exists(video_path):
                continue
            
            cap = cv2.VideoCapture(video_path)
            keypoints_seq = []
            while True:
                ret, frame = cap.read()
                if not ret:
                    break
                
                keypoints = extract_keypoints_from_frame(frame, mp_hands)
                if keypoints:
                    keypoints_seq.append(keypoints)

            cap.release()

            if keypoints_seq:
                np.save(os.path.join(output_dir, f"{video_id}.npy"), np.array(keypoints_seq))

    mp_hands.close()

if __name__ == "__main__":
    process_wlasl(
        json_path="data/wlasl_annotations.json",
        video_dir="data/raw",
        output_dir="data/processed"
    )
