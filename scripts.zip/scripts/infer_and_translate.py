import torch
import os
import sys
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
import cv2
import gradio as gr
import tempfile
import shutil

import numpy as np
from transformers import T5ForConditionalGeneration, T5Tokenizer, MarianMTModel, MarianTokenizer
from gtts import gTTS
import pyttsx3

# Import your custom recognizer model
from models.recognizer import SignLanguageTransformer  # Your custom transformer

# ====================
# Model Loader
# ====================
def load_model(model_path, model_type="recognizer"):
    if model_type == "recognizer":
        model = SignLanguageTransformer(input_size=63, num_classes=2000) # TODO: Fill in model args
        model.load_state_dict(torch.load(model_path, map_location=torch.device('cpu')))
        model.eval()
        print(f"[INFO] Loaded recognizer model from {model_path}")
        return model

    elif model_type == "decoder":
        tokenizer = T5Tokenizer.from_pretrained("t5-small")
        model = T5ForConditionalGeneration.from_pretrained("t5-small")
        model.eval()
        print(f"[INFO] Loaded T5 decoder model")
        return model, tokenizer

    elif model_type == "grammar_correction":
        tokenizer = T5Tokenizer.from_pretrained("t5-small")
        model = T5ForConditionalGeneration.from_pretrained("t5-small")
        model.eval()
        print(f"[INFO] Loaded grammar correction model")
        return model, tokenizer

    else:
        raise ValueError("Unsupported model type")

# ====================
# Preprocessing
# ====================
def preprocess_video(video_path):
    cap = cv2.VideoCapture(video_path)
    frames = []

    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break
        frame_resized = cv2.resize(frame, (224, 224))
        frames.append(frame_resized)

    cap.release()
    frames_tensor = torch.tensor(np.array(frames)).permute(0, 3, 1, 2).float()
    return frames_tensor.unsqueeze(0)  # Shape: (1, T, C, H, W)

# ====================
# Recognition
# ====================
def recognize_gesture(model, video_path):
    # Preprocess the video to get the frames tensor
    frames_tensor = preprocess_video(video_path)
    print("Original shape of frames_tensor:", frames_tensor.shape)

    # Flatten the frames from (B, T, C, H, W) to (B, T, 63) to match the expected feature size
    B, T, C, H, W = frames_tensor.shape  # B=batch size, T=frames, C=channels, H=height, W=width
    frames_tensor = frames_tensor.reshape(B, T, -1)  # Flatten (C, H, W) into a single dimension
    
    # If the model expects 63 features per frame, we might need to adjust this.
    # For example, reducing the features to 63 (this is just a placeholder for your actual implementation)
    frames_tensor = frames_tensor[:, :, :63]  # Take the first 63 features if needed
    
    print("New shape of frames_tensor:", frames_tensor.shape)

    # Pass the reshaped tensor to the model
    output = model(frames_tensor)  # Assumes your model returns logits

    # Get the predicted gesture class
    prediction = output.argmax(1).item()
    return prediction



# ====================
# Decode & Translate
# ====================
def decode_text(model, tokenizer, gesture_label):
    text = str(gesture_label)
    inputs = tokenizer(text, return_tensors="pt")
    outputs = model.generate(inputs["input_ids"], max_length=50)
    return tokenizer.decode(outputs[0], skip_special_tokens=True)

def correct_grammar(text):
    model, tokenizer = load_model(None, model_type="grammar_correction")
    corrected = decode_text(model, tokenizer, "Correct this sentence: " + text)
    return corrected

def translate_text(text, target_language="fr"):
    model_name = f"Helsinki-NLP/opus-mt-en-{target_language}"
    tokenizer = MarianTokenizer.from_pretrained(model_name)
    model = MarianMTModel.from_pretrained(model_name)
    tokens = tokenizer(text, return_tensors="pt", padding=True)
    translated_tokens = model.generate(**tokens)
    return tokenizer.decode(translated_tokens[0], skip_special_tokens=True)

# ====================
# Speech
# ====================
def text_to_speech(text, use_gtts=False):
    if use_gtts:
        tts = gTTS(text=text, lang='en')
        tts.save("output.mp3")
        os.system("start output.mp3")
    else:
        engine = pyttsx3.init()
        engine.say(text)
        engine.runAndWait()

    print(f"[INFO] Speech: {text}")

# ====================
# Pipeline
# ====================
def infer_and_translate(video_path, model_paths, use_gtts=False):
    recognizer_model = load_model(model_paths['recognizer'], model_type="recognizer")
    decoder_model, tokenizer = load_model(model_paths['decoder'], model_type="decoder")

    gesture_label = recognize_gesture(recognizer_model, video_path)
    print(f"[INFO] Recognized gesture label: {gesture_label}")

    generated_text = decode_text(decoder_model, tokenizer, gesture_label)
    print(f"[INFO] Generated text: {generated_text}")

    corrected_text = correct_grammar(generated_text)
    print(f"[INFO] Corrected text: {corrected_text}")

    translated_text = translate_text(corrected_text, target_language="fr")
    print(f"[INFO] Translated text: {translated_text}")

    text_to_speech(translated_text, use_gtts=use_gtts)
    print(f"[INFO] Final Output: {translated_text}")

def gradio_pipeline(video):
    # Save the video to a temporary path
    with tempfile.NamedTemporaryFile(delete=False, suffix=".mp4") as tmpfile:
        shutil.copy(video, tmpfile.name)
        video_path = tmpfile.name

    model_paths = {
        'recognizer': 'C:/Users/DELL/Desktop/NLP_CV_Project/sign2speak/saved_models/sign_recognizer_transformer_updated.pth',
        'decoder': 't5-small'
    }

    recognizer_model = load_model(model_paths['recognizer'], model_type="recognizer")
    decoder_model, tokenizer = load_model(model_paths['decoder'], model_type="decoder")

    gesture_label = recognize_gesture(recognizer_model, video_path)
    generated_text = decode_text(decoder_model, tokenizer, gesture_label)
    corrected_text = correct_grammar(generated_text)
    translated_text = translate_text(corrected_text, target_language="fr")

    return (
        f"Recognized gesture label: {gesture_label}",
        f"Generated text: {generated_text}",
        f"Corrected text: {corrected_text}",
        f"Translated text (French): {translated_text}"
    )

# Launch Gradio app
demo = gr.Interface(
    fn=gradio_pipeline,
    inputs=gr.Video(label="Upload or Record a Sign Language Video"),
    outputs=[
        gr.Textbox(label="Gesture Label"),
        gr.Textbox(label="Generated Text"),
        gr.Textbox(label="Grammar Corrected Text"),
        gr.Textbox(label="Translated Text (French)")
    ],
    title="Sign2Speak - Real-time Sign Language Translator",
    description="Upload or record a sign language video to recognize and translate gestures into spoken language."
)

# ====================
# Run the pipeline
# ====================
if __name__ == "__main__":
    demo.launch()
    video_path = "C:/Users/DELL/Desktop/NLP_CV_Project/sign2speak/data/raw/00626.mp4"
    model_paths = {
        'recognizer': 'C:/Users/DELL/Desktop/NLP_CV_Project/sign2speak/saved_models/sign_recognizer_transformer_updated.pth',
        'decoder': 't5-small'
    }

    infer_and_translate(video_path, model_paths, use_gtts=False)
