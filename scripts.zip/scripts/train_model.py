import os
import sys
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

import torch
import pandas as pd
from torch.utils.data import Dataset, DataLoader
from torch.nn.utils.rnn import pad_sequence
from sklearn.preprocessing import LabelEncoder
from models.recognizer import SignLanguageTransformer  # Updated class name
import torch.nn.functional as F
from tqdm import tqdm

# Top-K Accuracy Function
def top_k_accuracy(output, target, k=5):
    topk = torch.topk(output, k, dim=1).indices
    match = topk.eq(target.view(-1, 1).expand_as(topk))
    return match.any(dim=1).float().mean().item()

# Dataset Class
class SignLanguageDataset(Dataset):
    def __init__(self, df, root_dir, label_encoder, transform=None):
        self.root_dir = root_dir
        self.label_encoder = label_encoder
        self.transform = transform
        # Ensure only rows with existing keypoint files are included
        self.df = df[df['video_id'].apply(lambda vid: os.path.exists(os.path.join(root_dir, f"{vid}.pt")))].reset_index(drop=True)
        print(f"[INFO] Loaded {len(self.df)} samples with existing keypoint files.")

    def __len__(self):
        return len(self.df)

    def __getitem__(self, idx):
        row = self.df.iloc[idx]
        video_id = row["video_id"]
        label = self.label_encoder.transform([row["label"]])[0]
        keypoint_path = os.path.join(self.root_dir, f"{video_id}.pt")

        try:
            keypoints = torch.load(keypoint_path)  # [T, K]
        except Exception as e:
            print(f"[ERROR] Failed to load {keypoint_path}: {e}")
            return None

        if self.transform:
            keypoints = self.transform(keypoints)

        return keypoints, label

# Collate Function
def custom_collate_fn(batch):
    batch = [b for b in batch if b is not None and b[0] is not None]
    if len(batch) == 0:
        return None, None

    keypoints, labels = zip(*batch)
    keypoints_padded = pad_sequence(keypoints, batch_first=True).float()  # (B, T, K)
    labels_tensor = torch.tensor(labels)
    return keypoints_padded, labels_tensor

# Load CSVs
train_df = pd.read_csv("C:/Users/DELL/Desktop/NLP_CV_Project/sign2speak/data/train.csv")
val_df = pd.read_csv("C:/Users/DELL/Desktop/NLP_CV_Project/sign2speak/data/val.csv")

# Encode Labels
label_encoder = LabelEncoder()
label_encoder.fit(train_df["label"])
num_classes = len(label_encoder.classes_)

# Create Datasets and Loaders
train_dataset = SignLanguageDataset(df=train_df, root_dir='C:/Users/DELL/Desktop/NLP_CV_Project/sign2speak/keypoints', label_encoder=label_encoder)
val_dataset = SignLanguageDataset(df=val_df, root_dir='C:/Users/DELL/Desktop/NLP_CV_Project/sign2speak/keypoints', label_encoder=label_encoder)

train_loader = DataLoader(train_dataset, batch_size=4, shuffle=True, collate_fn=custom_collate_fn)
val_loader = DataLoader(val_dataset, batch_size=4, collate_fn=custom_collate_fn)

# Model Setup
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# Automatically find a valid sample file to infer input_size
sample_keypoints = None
for video_id in train_df['video_id']:
    path = os.path.join('C:/Users/DELL/Desktop/NLP_CV_Project/sign2speak/keypoints', f"{video_id}.pt")
    if os.path.exists(path):
        try:
            sample_keypoints = torch.load(path)
            break
        except Exception as e:
            print(f"[WARNING] Could not load {path}: {e}")
            continue

if sample_keypoints is None:
    raise RuntimeError("No valid keypoint file found to infer input size.")

input_size = sample_keypoints.size(1)

model = SignLanguageTransformer(input_size=input_size, num_classes=num_classes).to(device)
optimizer = torch.optim.AdamW(model.parameters(), lr=0.001)
loss_fn = torch.nn.CrossEntropyLoss()

# Training Loop
for epoch in range(100):  # You can increase later
    model.train()
    train_loss, correct, total = 0, 0, 0

    for batch in tqdm(train_loader, desc=f"Epoch {epoch+1} Training"):
        if batch[0] is None:
            continue
        x, y = batch
        x, y = x.to(device), y.to(device)
        out = model(x)
        loss = loss_fn(out, y.long())

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        train_loss += loss.item()
        correct += (out.argmax(1) == y).sum().item()
        total += y.size(0)

    print(f"Epoch {epoch+1}: Loss={train_loss:.3f}, Accuracy={correct/total:.3f}")

    # Validation
    model.eval()
    val_loss, val_correct, val_total, top5_acc = 0, 0, 0, 0

    with torch.no_grad():
        for batch in tqdm(val_loader, desc=f"Epoch {epoch+1} Validation"):
            if batch[0] is None:
                continue
            x, y = batch
            x, y = x.to(device), y.to(device)
            out = model(x)
            loss = loss_fn(out, y.long())

            val_loss += loss.item()
            val_correct += (out.argmax(1) == y).sum().item()
            val_total += y.size(0)
            top5_acc += top_k_accuracy(out, y, k=5)

    print(f"Validation Loss: {val_loss/len(val_loader):.3f}, Accuracy: {val_correct/val_total:.3f}, Top-5 Accuracy: {top5_acc/len(val_loader):.3f}")

# Save Model
os.makedirs("saved_models", exist_ok=True)
torch.save(model.state_dict(), "saved_models/sign_recognizer_transformer_updated.pth")
print("[INFO] Model saved to 'saved_models/sign_recognizer_transformer_updated.pth'")
