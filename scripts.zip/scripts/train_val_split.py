import json
import pandas as pd
from sklearn.model_selection import train_test_split

# Load the WLASL annotation file
with open("data/wlasl_annotations.json", "r") as f:
    data = json.load(f)

# Build a DataFrame with video_id and label (gloss)
samples = []
for entry in data:
    label = entry['gloss']
    for instance in entry['instances']:
        if instance['video_id']:  # Skip if video_id is missing
            samples.append({
                'video_id': instance['video_id'],
                'label': label
            })

df = pd.DataFrame(samples)

# Optional: Save the full dataset if needed
df.to_csv("annotations.csv", index=False)

# Split into training and validation sets
train_df, val_df = train_test_split(df, test_size=0.2, stratify=df["label"], random_state=42)

# Save to CSV files
train_df.to_csv("train.csv", index=False)
val_df.to_csv("val.csv", index=False)

print("Train/Val split complete.")
