from gtts import gTTS
import os

class SpeechSynthesizer:
    def __init__(self, lang="en"):
        self.lang = lang

    def synthesize(self, text, output_path="output.mp3"):
        tts = gTTS(text, lang=self.lang)
        tts.save(output_path)
        return output_path  # Path to the saved audio file
